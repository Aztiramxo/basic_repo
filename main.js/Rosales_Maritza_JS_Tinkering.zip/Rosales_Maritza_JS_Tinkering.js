var childHeight = 58; 
function displayIfChildIsAbleToRideTheRollerCoaster() {
    if (childHeight >= 54) {
    console.log("Get on that ride Kiddo!");
    }
    else {
    console.log("Sorry maybe next year kiddo.");
    }
}
displayIfChildIsAbleToRideTheRollerCoaster(childHeight);
